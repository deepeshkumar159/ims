
from django.db import models
from django.contrib.auth.models import User

ORDER_STATUS = (
    ('Pending', 'Pending'),
    ('Delivered', 'Delivered'),
    ('Canceled', 'Canceled'),
    ('Shipped', 'Shipped'),
    ('Refunded', 'Refunded'),
    ('Completed', 'Completed'),
    ('Out for delivery', 'Out for delivery'),
)

PRODUCT_CATEGORY = (
    ('Clothes', 'Clothes'),
    ('Accessories', 'Accessories'),
    ('Electronics', 'Electronics'),
    ('Furniture', 'Furniture'),
    ('Grocery', 'Grocery'),
    ('Health', 'Health'),
    ('Home', 'Home'),
    ('Kitchen', 'Kitchen'),
    ('Office', 'Office'),
    ('Unknown', 'Unknown'),
)

class Customer(models.Model):
    customer_id = models.AutoField(primary_key=True)
    profile_pic= models.ImageField(null=True , blank=True)
    username = models.CharField(max_length=100, unique=True)
    phone = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.username

class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    profile_pic= models.ImageField(null=True , blank=True)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=0)
    category = models.CharField(max_length=100, choices=PRODUCT_CATEGORY)
    discription = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.name
    
class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    Customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    status = models.CharField(max_length=100, choices=ORDER_STATUS)
    created_on = models.DateTimeField(auto_now_add=True)
    def save(self, *args, **kwargs):
        if self.quantity <= self.product.quantity and self.quantity != 0:
            self.product.quantity -= self.quantity
            self.product.save()
            super(Order, self).save(*args, **kwargs)
        else:
            raise ValueError('Product stock is low')
    def __str__(self):
        template = '{0.created_on} :: {0.Customer} : {0.product} : {0.quantity}'
        return template.format(self)
    
    
class offers(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    discription = models.CharField(max_length=100)
    def __str__(self):
        return self.name