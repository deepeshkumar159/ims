from django.shortcuts import render, redirect
from accounts.models import *
from .forms import *
from .filters import *
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from datetime import datetime, timedelta

def index(request):
    offer = offers.objects.all()
    return render(request, 'index.html', {'offer': offer})

def home(request):
    context = {
        'all_order': Order.objects.all().order_by('-order_id')[:5],
        'total_orders': Order.objects.all().count(), 
        'order_pending': Order.objects.filter(status='Pending').count(), 
        'order_delivered': Order.objects.filter(status='Delivered').count(), 
        'order_cancelled': Order.objects.filter(status='Canceled').count(),
        }
    return render(request, 'dashboard.html', context)

def report(request):
    last_month = datetime.now().date() - timedelta(days=30)  # assuming a month has 30 days
    context = {
        'all_order': Order.objects.filter(date__month=last_month.month),
        'total_orders': Order.objects.all().count(), 
        'order_pending': Order.objects.filter(status='Pending').count(), 
        'order_delivered': Order.objects.filter(status='Delivered').count(), 
        'order_cancelled': Order.objects.filter(status='Canceled').count(),
        }
    return render(request, 'dashboard.html', context)

def orders(request):
    all_order=Order.objects.all()
    myFilter = OrderFilter(request.GET, queryset=all_order)
    all_order = myFilter.qs
    context = {
        'all_order': all_order,
        'myFilter': myFilter,
    }
    return render(request, 'orders.html', context)

def products(request):
    all_products=Product.objects.all
    context = {
        'all_products': all_products
    }
    return render(request, 'all_products.html',context)

def customer_view(request, username):
    offer = offers.objects.all()
    customer=Customer.objects.get(username=username)
    orders=customer.order_set.all()
    orders_count=orders.count()
    orders_pending=customer.order_set.filter(status='Pending')
    orders_pending_count=orders_pending.count()
    orders_delivered=customer.order_set.filter(status='Delivered')
    orders_delivered_count=orders_delivered.count()
    orders_cancelled=customer.order_set.filter(status='Canceled')
    orders_cancelled_count=orders_cancelled.count()
    context ={
        'customer': customer,
        'orders': orders,
        'orders_count': orders_count,
        'orders_pending': orders_pending,
        'orders_pending_count': orders_pending_count,
        'orders_delivered': orders_delivered,
        'orders_delivered_count': orders_delivered_count,
        'orders_cancelled': orders_cancelled,
        'orders_cancelled_count': orders_cancelled_count,
        'offer': offer    
    }
    return render(request, 'customer.html', context)                 

 
def products_view(request, product_id):
    products=Product.objects.get(product_id=product_id)
    orders=products.order_set.all()
    orders_count=orders.count()
    orders_pending=products.order_set.filter(status='Pending')
    orders_pending_count=orders_pending.count()
    orders_delivered=products.order_set.filter(status='Delivered')
    orders_delivered_count=orders_delivered.count()
    orders_cancelled=products.order_set.filter(status='Canceled')
    orders_cancelled_count=orders_cancelled.count()
    context ={
        'products': products,
        'orders': orders,
        'orders_count': orders_count,
        'orders_pending': orders_pending,
        'orders_pending_count': orders_pending_count,
        'orders_delivered': orders_delivered,
        'orders_delivered_count': orders_delivered_count,
        'orders_cancelled': orders_cancelled,
        'orders_cancelled_count': orders_cancelled_count    
    }
    return render(request, 'products.html', context)                 


def create_order(request):
    form = OrderForm()
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context ={
        'form': form
    }
    return render(request, 'form.html', context)


def create_product(request):
    form = ProductForm()
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context ={
        'form': form
    }
    return render(request, 'form.html', context)


def create_customer(request):
    form = CustomerForm()
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context ={
        'form': form
    }
    return render(request, 'form.html', context)


def update_order(request, order_id):
    order = Order.objects.get(order_id=order_id)
    form = OrderForm(instance=order)
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request, 'form.html', {'form': form})
    

def delete_order(request, order_id):
    order = Order.objects.get(order_id=order_id)
    if request.method == 'POST':
            order.delete()
            return redirect('/')
    return render(request, 'delete.html', {'order_id': order_id})

    
def update_customer(request, customer_id):
    customer = Customer.objects.get(customer_id=customer_id)
    form = CustomerForm(instance=customer)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request, 'form.html', {'form': form})

    
def update_product(request, product_id):
    products = Product.objects.get(product_id=product_id)
    form = ProductForm(instance=products)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=products)
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request, 'form.html', {'form': form})


def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return render(request, 'home')
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="register.html", context={"register_form":form})

def login_view(request):
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('Home') # replace 'home' with your desired URL
        else:
            error_message = 'Invalid login credentials'
            return render(request, 'login.html', {'error_message': error_message , 'form': form})
    else:
        return render(request, 'login.html', {'form': form})



def register_request_cust(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return render(request, 'customer/<str:username>')
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="register.html", context={"register_form":form})

def login_view_cust(request):
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('Customers', username=username) # replace 'home' with your desired URL
        else:
            error_message = 'Invalid login credentials'
            return render(request, 'login.html', {'error_message': error_message , 'form': form})
    else:
        return render(request, 'login.html', {'form': form})





def logout_view(request):
    logout(request)
    return redirect('home')
