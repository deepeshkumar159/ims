from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index, name='index'),
    path('home', views.home, name='Home'),
    path('report', views.report, name='report'),
    path('products/', views.products, name='Products'),
    path('products/<int:product_id>/', views.products_view, name='Products'),
    path('customer/<str:username>/', views.customer_view, name='Customers'),
    path('orders', views.orders, name='orders'),
    path('create_order', views.create_order, name='create_order'),
    path('update_order/<int:order_id>', views.update_order, name='update_order'),
    path('delete_order/<int:order_id>', views.delete_order, name='delete_order'),
    path('create_product', views.create_product, name='create_product'),
    path('update_product/<int:product_id>', views.update_product, name='update_product'),
    path('create_customer', views.create_customer, name='create_customer'),
    path('update_customer/<int:customer_id>', views.update_customer, name='update_customer'),
    path("register", views.register_request, name="register"),
    path("login", views.login_view, name="login"),
    path("register_cust", views.register_request_cust, name="register_cust"),
    path("login_cust", views.login_view_cust, name="login_cust"),
    path('logout/', views.logout_view, name='logout'),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)